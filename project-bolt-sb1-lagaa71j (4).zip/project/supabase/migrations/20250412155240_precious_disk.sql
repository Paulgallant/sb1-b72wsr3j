/*
  # Initial Schema Setup

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key, references auth.users)
      - `username` (text, unique)
      - `account_type` (text)
      - `created_at` (timestamp)
    - `payment_settings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `payment_method` (text)
      - `bank_account` (text, nullable)
      - `routing_number` (text, nullable)
      - `crypto_address` (text, nullable)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  account_type text NOT NULL CHECK (account_type IN ('personal', 'business', 'creator')),
  created_at timestamptz DEFAULT now()
);

-- Create payment_settings table
CREATE TABLE IF NOT EXISTS payment_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  payment_method text NOT NULL CHECK (payment_method IN ('bank', 'crypto')),
  bank_account text,
  routing_number text,
  crypto_address text,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_bank_info CHECK (
    (payment_method = 'bank' AND bank_account IS NOT NULL AND routing_number IS NOT NULL) OR
    (payment_method = 'crypto' AND crypto_address IS NOT NULL) OR
    (bank_account IS NULL AND routing_number IS NULL AND crypto_address IS NULL)
  )
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_settings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
    DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
    DROP POLICY IF EXISTS "Users can view own payment settings" ON payment_settings;
    DROP POLICY IF EXISTS "Users can update own payment settings" ON payment_settings;
    DROP POLICY IF EXISTS "Users can insert own payment settings" ON payment_settings;
EXCEPTION
    WHEN undefined_object THEN
        NULL;
END $$;

-- Policies for profiles
CREATE POLICY "Users can view own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Policies for payment_settings
CREATE POLICY "Users can view own payment settings"
  ON payment_settings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own payment settings"
  ON payment_settings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own payment settings"
  ON payment_settings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);