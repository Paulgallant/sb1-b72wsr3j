/*
  # Payment Settings Table

  1. New Tables
    - `payment_settings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `payment_method` (text)
      - `bank_account` (text, nullable)
      - `routing_number` (text, nullable)
      - `crypto_address` (text, nullable)
      - `created_at` (timestamptz)
      
  2. Security
    - Enable RLS
    - Add policies for user access control
*/

CREATE TABLE IF NOT EXISTS payment_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) NOT NULL,
  payment_method TEXT NOT NULL CHECK (payment_method IN ('bank', 'crypto')),
  bank_account TEXT,
  routing_number TEXT,
  crypto_address TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  CONSTRAINT valid_bank_details CHECK (
    (payment_method = 'bank' AND bank_account IS NOT NULL AND routing_number IS NOT NULL AND crypto_address IS NULL) OR
    (payment_method = 'crypto' AND crypto_address IS NOT NULL AND bank_account IS NULL AND routing_number IS NULL)
  )
);

-- Enable RLS
ALTER TABLE payment_settings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Users can view own payment settings" ON payment_settings;
    DROP POLICY IF EXISTS "Users can update own payment settings" ON payment_settings;
    DROP POLICY IF EXISTS "Users can insert own payment settings" ON payment_settings;
EXCEPTION
    WHEN undefined_object THEN
        NULL;
END $$;

-- Create policies
CREATE POLICY "Users can view own payment settings"
  ON payment_settings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own payment settings"
  ON payment_settings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own payment settings"
  ON payment_settings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);