/*
  # Initial Schema Setup for Seeking You Platform

  1. New Tables
    - profiles
      - Stores user profile information
      - Links to Supabase auth.users
    - payment_settings
      - Stores user payment preferences and details
    - stream_sessions
      - Records live streaming sessions
    - gifts
      - Tracks gifts sent between users

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  account_type TEXT NOT NULL CHECK (account_type IN ('personal', 'business', 'creator')),
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Create payment_settings table
CREATE TABLE IF NOT EXISTS payment_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) NOT NULL,
  payment_method TEXT NOT NULL CHECK (payment_method IN ('bank', 'crypto')),
  bank_account TEXT,
  routing_number TEXT,
  crypto_address TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  UNIQUE(user_id)
);

-- Create stream_sessions table
CREATE TABLE IF NOT EXISTS stream_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) NOT NULL,
  duration INTEGER NOT NULL,
  earnings DECIMAL(10,2) DEFAULT 0,
  started_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  ended_at TIMESTAMPTZ
);

-- Create gifts table
CREATE TABLE IF NOT EXISTS gifts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id UUID REFERENCES profiles(id) NOT NULL,
  receiver_id UUID REFERENCES profiles(id) NOT NULL,
  gift_type TEXT NOT NULL CHECK (gift_type IN ('heart', 'star', 'diamond')),
  amount DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE stream_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE gifts ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can read any profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Payment settings policies
CREATE POLICY "Users can read own payment settings"
  ON payment_settings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own payment settings"
  ON payment_settings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own payment settings"
  ON payment_settings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Stream sessions policies
CREATE POLICY "Users can read own stream sessions"
  ON stream_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own stream sessions"
  ON stream_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own stream sessions"
  ON stream_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Gifts policies
CREATE POLICY "Users can read gifts they sent or received"
  ON gifts FOR SELECT
  TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can insert gifts they send"
  ON gifts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id);