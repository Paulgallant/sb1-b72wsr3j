/*
  # Business Subscriptions Schema

  1. New Tables
    - `business_subscriptions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `start_date` (timestamptz)
      - `end_date` (timestamptz)
      - `status` (text)
      - `amount_paid` (decimal)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for business users
*/

CREATE TABLE IF NOT EXISTS business_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) NOT NULL,
  start_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  end_date TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('active', 'expired', 'cancelled')),
  amount_paid DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE business_subscriptions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own subscriptions"
  ON business_subscriptions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own subscriptions"
  ON business_subscriptions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);